
//
//  Cancer.swift
//  Development
//
//  Created by Mason Dierkes on 4/10/21.
//

import Foundation

public struct CancerInfo{
    public var type: String
    public var description: String
    public var image: String
}
