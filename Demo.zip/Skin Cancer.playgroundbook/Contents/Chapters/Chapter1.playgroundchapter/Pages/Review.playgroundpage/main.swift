//#-hidden-code
import PlaygroundSupport
import SwiftUI
//#-end-hidden-code
/*:

# Concluding Notes

### We've learned a lot in the last view minutes, so let's recap.

Skin Cancer is dangerous and harmful disease that effects people all around the world. Often it develops from the sun exposure when you are a child and you are unaware of the dangerous consequences. 


Test your knowledge on the right-hand side of the screen, feel free to go back a few pages if needed.

Thank you for taking the time to review my Swift Playground. I hope that I was able to bring awareness to the dangers of skin cancer.  - Mason Dierkes

This playground is dedicated to Raymond "Mosfet" DiPerna ❤️


*/
let page = ReviewPage()
PlaygroundPage.current.setLiveView(page)

